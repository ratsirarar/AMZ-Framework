<?php
/**
 * Sass parser.
 *
 * @link http://haml.hamptoncatlin.com/ Original Haml&Sass parser (for Ruby)
 * @license http://www.opensource.org/licenses/mit-license.php MIT (X11) License
 * @author Amadeusz Jasak <amadeusz.jasak@gmail.com>
 * @package phpHaml
 */

/**
 * Sass parser.
 *
 * @link http://haml.hamptoncatlin.com/ Original Haml&Sass parser (for Ruby)
 * @license http://www.opensource.org/licenses/mit-license.php MIT (X11) License
 * @author Amadeusz Jasak <amadeusz.jasak@gmail.com>
 * @package phpHaml
 */
class SassParser
{
	
}
?>